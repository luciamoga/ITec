﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
namespace DelightOptimization
{
    public partial class LoginFrm : Form
    {
        public LoginFrm()
        {
            InitializeComponent();
        }

        int languageEN = 1;
        string conString;
        private void loadFormText()
        {/*
            int x = languageEN;
            string[] lines = System.IO.File.ReadAllLines("loginForm.txt.");
            lblUser.Text = lines[x]; x += 2;
            lblPass.Text = lines[x]; x += 2;
            btnLogin.Text = lines[x]; x += 2;
            lblProblem.Text = lines[x]; x += 2;
            lblInstruction.Text = lines[x]; x += 2;
            */
        }
        private void LoginFrm_Load(object sender, EventArgs e)
        {
            conString = DelightOptimization.Properties.Resources.ConnectionString;
            try
            {
                OleDbConnection con = new OleDbConnection(conString);
                con.Open();
                con.Close();
            }
            catch
            {
                if (opf.ShowDialog() == DialogResult.OK)
                {
                    conString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + opf.FileName + ";Persist Security Info=True";
                    DelightOptimization.Properties.Resources.ConnectionString.Replace(DelightOptimization.Properties.Resources.ConnectionString, conString);
                    
                }

            }
           
            loadFormText();

        }

        private void languageChoice_Click(object sender, EventArgs e)
        {
            /*
            if (languageEN == 0)
            { languageEN = 1; languageChoice.Text = "English"; }
            else { languageEN = 0; languageChoice.Text = "Română"; }
            loadFormText();
             */
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            
            OleDbConnection myConnection = new OleDbConnection(conString);
            myConnection.Open();
            OleDbCommand comm = new OleDbCommand("select welcomeText from Employees where ID = @id and pass = @pass", myConnection);
            comm.Parameters.AddWithValue("id", txtUser.Text);
            comm.Parameters.AddWithValue("pass", txtPass.Text);
            IDataReader reader = comm.ExecuteReader();
            String result = reader.Read().ToString(); 
            if (result=="False")
            {
                
                reader.Close();
                comm.CommandText = "select welcomeText from Admin where ID = @id and pass = @pass";
                IDataReader reader2 = comm.ExecuteReader();
                result = reader2.Read().ToString();
              
                if (result == "False") lblProblem.Visible = true;
                else
                {
                    
                    String welcome = reader2[0].ToString();
                    Admin adminForm = new Admin(txtUser.Text, welcome, languageEN);
                    myConnection.Close();
                    reader2.Close();
                    adminForm.ShowDialog();
                }
            }
            else
            {
                
                String welcome = reader[0].ToString();
                Employee employeeForm = new Employee(txtUser.Text, welcome, languageEN);
                myConnection.Close();
                reader.Close();
                employeeForm.ShowDialog();
            }
        }

        private void lblProblem_Click(object sender, EventArgs e)
        {

        }
    }
}
