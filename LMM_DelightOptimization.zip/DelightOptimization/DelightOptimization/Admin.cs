﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using System.Web;
using System.Data;
using System.Data.SqlClient;


namespace DelightOptimization
{
    public partial class Admin : Form
    {
        int languageEN;
        string connString = DelightOptimization.Properties.Resources.ConnectionString;

        public Admin(String ID, String welcomeMessage, int language)
        {
            languageEN = language;
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            tabControl1.Controls[0].Text = "Votes report";
            tabControl1.Controls[1].Text = "Groups general settings";
            tabControl1.Controls[2].Text = "Groups assignment settings";

            int i = 0;
            OleDbConnection con = new OleDbConnection(connString);
            con.Open();
            OleDbCommand com1 = new OleDbCommand("SELECT name, value, pointsReceived from Items", con);
            IDataReader reader = com1.ExecuteReader();
            while (reader.Read())
            {
                dgvTab1.Rows.Add();
                DataGridViewRow newRow = new DataGridViewRow();
                dgvTab1.Rows[i].Cells[0].Value = reader[0].ToString();
                dgvTab1.Rows[i].Cells[1].Value = reader[1].ToString();
                int a = int.Parse(reader[2].ToString());
                int b = int.Parse(reader[1].ToString());
                int votes = a / b;
                dgvTab1.Rows[i].Cells[2].Value = votes.ToString();
                dgvTab1.Rows[i].Cells[3].Value = votes.ToString();
                i++;

            }
            reader.Close();
            i = 0;
            OleDbCommand com2 = new OleDbCommand("Select name, welcomeMessage, noPoints from groups", con);
            IDataReader reader2 = com2.ExecuteReader();
            while (reader2.Read())
            {
                dgvTab2.Rows.Add();
                DataGridViewRow newRow = new DataGridViewRow();
                dgvTab2.Rows[i].Cells[0].Value = reader2[0].ToString();
                dgvTab2.Rows[i].Cells[1].Value = reader2[1].ToString();
                dgvTab2.Rows[i].Cells[2].Value = reader2[2].ToString();
                i++;

            }
            reader2.Close();

            i = 0;
            OleDbCommand com3 = new OleDbCommand("Select ID, name, surname, grp from Employees", con);
            IDataReader reader3 = com3.ExecuteReader();
            while (reader3.Read())
            {
                dgvTab3.Rows.Add();
                DataGridViewRow newRow = new DataGridViewRow();
                dgvTab3.Rows[i].Cells[0].Value = reader3[0].ToString();
                dgvTab3.Rows[i].Cells[1].Value = reader3[1].ToString();
                dgvTab3.Rows[i].Cells[2].Value = reader3[2].ToString();
                dgvTab3.Rows[i].Cells[3].Value = reader3[3].ToString();
                i++;

            }
            reader3.Close();
            dgvTab1.Sort(dgvTab1.Columns[3], ListSortDirection.Descending);



            con.Close();

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void btnPopulate_Click(object sender, EventArgs e)
        {
            try
            {
                int budget = int.Parse(txtBudget.Text);
                foreach (DataGridViewRow row in dgvTab1.Rows)
                    row.Cells[3].Value = ((int.Parse(row.Cells[1].Value.ToString())) * budget);
            }
            catch (Exception ex)
            {


            }
        }

        private void dgvTab3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewCell cell = (DataGridViewCell)sender;
                // DataGridView cell = dgvTab3.
                if (cell.ColumnIndex == 4)
                {
                    OleDbConnection con = new OleDbConnection(connString);
                    con.Open();
                    OleDbCommand com = new OleDbCommand("UPDATE EMPLOYEES SET GROUP='" + dgvTab3.Rows[cell.RowIndex].Cells[3].Value + "' where ID='" + dgvTab3.Rows[cell.RowIndex].Cells[0].Value + "'", con);
                    com.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection con = new OleDbConnection(connString);
                con.Open();
                foreach (DataGridViewRow row in dgvTab3.Rows)
                {


                    OleDbCommand com = new OleDbCommand("UPDATE EMPLOYEES SET GRP='" + row.Cells[3].Value + "' where ID='" + row.Cells[0].Value + "'", con);
                    com.ExecuteNonQuery();
                }
                con.Close();
            }

            catch (Exception ex) { MessageBox.Show(ex.ToString()); }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection con = new OleDbConnection(connString);
                con.Open();
                foreach (DataGridViewRow row in dgvTab2.Rows)
                {
                    OleDbCommand com = new OleDbCommand("UPDATE Groups SET welcomeMessage='" + row.Cells[1].Value + "', noPoints="+row.Cells[2].Value+" where name='" + row.Cells[0].Value + "'", con);
                    OleDbCommand com2 = new OleDbCommand("UPDATE Employees SET welcomeText='" + row.Cells[1].Value + "', where grp='" + row.Cells[0].Value + "'", con);
                    com2.ExecuteNonQuery();
                    com.ExecuteNonQuery();
                }
                con.Close();
            }

            catch (Exception ex) {  }
        }
        int budget;

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int.Parse(txtTotalBudget.Text);
                btnSetBudget.Enabled = true;
            }
            catch
            {
                btnSetBudget.Enabled = false;
            }
        }

        private void btnSetBudget_Click(object sender, EventArgs e)
        {
            budget = int.Parse(txtTotalBudget.Text);
            dgvTab1.Sort(dgvTab1.Columns[3], ListSortDirection.Descending);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (checkBox1.Checked == true)
                {
                    int total = 0;
                    foreach (DataGridViewRow row in dgvTab1.Rows)
                    {
                        total += int.Parse(row.Cells[3].Value.ToString());
                        if (total > budget)
                            row.Visible = false;

                    }
                }
                else
                {
                    foreach (DataGridViewRow row in dgvTab1.Rows)
                        row.Visible = true;
                }
                
            }
            catch
            {
               // checkBox1.Checked = false;
                MessageBox.Show("Please set the budget!");
                
            }
        }
        public void exportData(DataGridView dgv)
        {
            string s = null;

            foreach (DataGridViewColumn dr in dgv.Columns)
                if (dr.Visible == true
                    ) s = s + dr.HeaderText + ",";
            s = s + "\r\n";
            sfd.Filter = "CSV File|*.csv";
            sfd.AddExtension = true;
            sfd.FileName = "";
            sfd.Title = "File name";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(sfd.FileName); sw.Write(s + "\r\n");
                s = null;

                for (int i = 0; i < dgv.Rows.Count - 1; i++)
                {
                    foreach (DataGridViewColumn dr in dgv.Columns)

                        if (dr.Visible == true && dgv.Rows[i].Cells[dr.Name].Visible == true)
                            s = s + dgv.Rows[i].Cells[dr.Name].Value.ToString() + ",";
                    sw.Write(s + "\r\n");
                    s = null;
                }
                sw.Close();
            }
        }
        private void export_Click(object sender, EventArgs e)
        {
            exportData(dgvTab1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            exportData(dgvTab2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            exportData(dgvTab3);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbConnection con = new OleDbConnection(connString);
                con.Open();
                foreach (DataGridViewRow row in dgvTab2.Rows)
                {


                    OleDbCommand com = new OleDbCommand("UPDATE EMPLOYEES SET points=points+" + row.Cells[2].Value + " where grp='" + row.Cells[0].Value + "'", con);
                    com.ExecuteNonQuery();
                }
                con.Close();
            }

            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }
    }
}

