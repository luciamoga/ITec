﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using System.Web;
using System.Data;
using System.Data.SqlClient;


namespace DelightOptimization
{
    public partial class Employee : Form
    {
        int languageEN;
        string wm, id;
        string connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + @"E:\University\Other\ITec 2014\DelightOptimization\DelightOptimization\database.mdb";
        public Employee(String ID, String welcomeMessage, int language)
        {
            languageEN = language;
            id=ID;
            wm=welcomeMessage;
            InitializeComponent();
        }
        string notEnoughPointsMessage;
        private void loadText()
        {
            OleDbConnection conn = new OleDbConnection(connString);
            conn.Open();
            OleDbCommand com = new OleDbCommand("select Points from Employees where ID='"+id+"'", conn);
            IDataReader reader = com.ExecuteReader();
            reader.Read();
            String points = reader[0].ToString();
            lblPointsNo.Text = points;

            conn.Close();
            reader.Close();

            int x = languageEN-1;
            string[] lines = System.IO.File.ReadAllLines("employeesForm.txt.");
            lblwelcome.Text=wm;
            lblPoints.Text=lines[x]; x += 2;
            btnSave.Text = lines[x]; x += 2;
            notEnoughPointsMessage = lines[x]; x += 2;
            
            
        }
        private void loadListBox()
        {
            
            OleDbConnection serverDBcon = new OleDbConnection(connString);
            serverDBcon.Open();
            OleDbCommand categoriesComm = new OleDbCommand("select name from Categories", serverDBcon);
            IDataReader categoryReader = categoriesComm.ExecuteReader();
         
            while (categoryReader.Read())
            {
                ListViewGroup group = new ListViewGroup(categoryReader[0].ToString(),HorizontalAlignment.Left);
                listItems.Groups.Add(group);
            }
            categoryReader.Close();
            foreach (ListViewGroup gr in listItems.Groups)
            {            
                OleDbCommand itemsComm = new OleDbCommand("select name, value from Items where category ='"+ gr.Header+"'", serverDBcon);

               // itemsComm.Parameters.("@category", gr.Header);
                IDataReader itemsReader = itemsComm.ExecuteReader();
                while (itemsReader.Read())
                {
                    ListViewItem newItem = new ListViewItem(itemsReader[0].ToString());
                    newItem.SubItems.Add(itemsReader[1].ToString());
                    newItem.Group = gr;
                    listItems.Items.Add(newItem);
                    
                }
                itemsReader.Close();
            }
            
            serverDBcon.Close();
          
        }
        private void updateLocalDB()
        {
           

        }
        private void Employee_Load(object sender, EventArgs e)
        {
           
            loadText();
            loadListBox();
        }

        private void listItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnAdd.Enabled = true;
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (listItems.SelectedItems[0].BackColor != Color.Gray)
            {
             
                int points = int.Parse(lblPointsNo.Text);
                if (points - int.Parse(listItems.SelectedItems[0].SubItems[1].Text) >= 0)
                {
                    listItems.SelectedItems[0].BackColor = Color.Gray;
                    btnRemove.Enabled = true;
                    points = points - int.Parse(listItems.SelectedItems[0].SubItems[1].Text);
                    lblPointsNo.Text = points.ToString();
                }
                else MessageBox.Show(notEnoughPointsMessage);
            }

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (listItems.SelectedItems[0].BackColor == Color.Gray)
            {
                listItems.SelectedItems[0].BackColor = Color.DeepSkyBlue;
                int points = int.Parse(lblPointsNo.Text);
                points = points + int.Parse(listItems.SelectedItems[0].SubItems[1].Text);
                lblPointsNo.Text = points.ToString();
                
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            OleDbConnection conn= new OleDbConnection(connString);
            conn.Open();
            foreach (ListViewItem item in listItems.Items)
            {
                if (item.BackColor == Color.Gray)
                {
                    String value = item.SubItems[1].Text;
                    String name = item.SubItems[0].Text;
                    OleDbCommand com1 = new OleDbCommand("UPDATE Items SET value = '"+value+"' where name= '"+name+"'", conn);
                    com1.ExecuteNonQuery();
                    OleDbCommand com2 = new OleDbCommand("UPDATE Employees SET points ='"+value+"'where ID='"+id+"'", conn);
                    com2.ExecuteNonQuery();
                }
            }

            conn.Close();
        }
       
    }
}
